'''
Criptografia
'''

nums = input('Digite o número de 4 algarismos: ')
n = [0, 0, 0, 0]

'''
Verificando quais números somados com 6 são maiores que 10
para quando descriptografá-lo subtrair 6 e somar 10 para voltar ao número original
'''
for i in range(len(nums)):
    if int(nums[i]) - 6 < 0:
        n[i] = int(nums[i]) + 4
    else:
        n[i] = int(nums[i]) - 6

'''
Fazendo a troca de algarismos
'''
aux = n[0]
n[0] = n[2]
n[2] = aux
aux = n[1]
n[1] = n[3]
n[3] = aux

'''
Montando a lista de inteiros em uma string e mostrando como inteiro
'''
mens = int(str(n[0]) + str(n[1]) + str(n[2]) + str(n[3]))

print(mens)