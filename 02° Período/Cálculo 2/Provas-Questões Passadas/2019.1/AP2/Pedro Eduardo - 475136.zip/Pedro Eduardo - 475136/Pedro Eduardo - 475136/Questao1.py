'''
Números Complexos
'''

class Complexo(object):
    
    #Recebe os valores real e imaginário do número complexo instanciado
    def iniciaNumero(self, a, b):
        self.a = a
        self.b = b

    #Imprime o número complexo no terminal de acordo com sua notação
    def imprimeNumero(self):
        print(f'{self.a} + {self.b}i')

    #Verifica se o obj número complexo é igual ao valor passado como parâmetro
    def eIgual(self, c, d):
        return self.a == c and self.b == d

    #Soma o obj número complexo instanciado com um novo numero passado como parâmetro
    def soma(self, c, d):
        print(f'{self.a + c} + {self.b + d}i')

    #Subtrai o obj número complexo instanciado com um novo numero passado como parâmetro
    def subtrai(self, c, d):
        print(f'{self.a - c} + {self.b - d}i')
 
    #Multiplica o obj número complexo instanciado com um novo numero passado como parâmetro
    def multiplica(self, c, d):
        print(f'{(self.a * c) - (self.b * d)} + {(self.a * d) + (self.b * c)}i')

    #Divide o obj número complexo instanciado com um novo numero passado como parâmetro
    def divide(self, c, d):
        print(f'{(self.a * c) + (self.b * d) / (c**2 + d**2)} + {(self.b * c) - (self.a * d) / (c**2 + d**2)}i')
