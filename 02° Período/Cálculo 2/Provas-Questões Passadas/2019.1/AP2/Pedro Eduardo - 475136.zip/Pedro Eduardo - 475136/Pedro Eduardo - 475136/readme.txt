Trabalho final - Python

Antes de executar os códigos em si:
• Windows: Primeiramente deve-se instalar o Python na máquina, para estes códigos foi usado a versão 3.9.0 do Python.
• Linux e Mac OS: Por padrão o Python já vem instalado nesses sistemas operacionais, mas é recomendado utilizar a mesma versão em que os progrmas foram escritos e abrir os arquivos terminal em alguma IDE ou na IDLE.

Como executar os códigos:
Para usar as funcionalidades do código Questao1.py, de números complexos, é preciso criar outro arquivo.py para fazer a importação da classe do questao01.py, instanciar um objeto da classe Complexo e utilizar os métodos pertecentes a classe.
O arquivo Questao2.py basta abrir no terminal ou IDE e executar.