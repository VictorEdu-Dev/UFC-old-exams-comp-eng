print("Converter segundos em dias, horas, minutos e segundos")

seg_str = input("Digite o número de segundos a ser convertido: ")

segtotal = int(seg_str)

horas = segtotal // 3600
dias = horas // 86400

segresta = segtotal % 3600
minutos = segresta // 60

segrestafinais = segresta % 60

if(horas >= 24):

    dias = int(horas / 24)
    horas = int(horas % 24)

print(dias, "dias,", horas, "horas,", minutos, "minutos e", segrestafinais, "segundos.")

