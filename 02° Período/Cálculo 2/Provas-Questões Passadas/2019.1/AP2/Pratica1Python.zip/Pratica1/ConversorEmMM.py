print("Conversão de metros para milímetros")

num1 = input("Numero em metros:")

som = float(num1)*1000

print("O valor de {0} metros em milímetros é {1}".format(num1,som))
